#!/bin/bash

#********Do not modify this file. If you want modify this file, pls contact our FAE*******
echo ""
echo "# begin fota properties"
echo "ro.fota.platform=MTK6739_8.1"
#type info: phone, pad ,box, tv
echo "ro.fota.type=phone"
echo "ro.fota.app=5"
echo "ro.fota.battery=30"
echo "ro.boot.vendor.overlay.theme=com.adups.fota.overlay"
#oem info
echo "ro.fota.oem=waterworld16739_8.1"
#model info, Settings->About phone->Model number
FotaDevice=$(grep "ro.product.model=" "$1"|awk -F "=" '{print $NF}' )
echo "ro.fota.device=$FotaDevice" | sed  's/[^0-9a-zA-Z= ._-]//g'
#version number, Settings->About phone->Build number
#FotaVersion=$(grep "ro.build.display.id=" "$1"|awk -F "=" '{print $NF}' )
FotaVersion=$(grep "ro.build.display.id=" "$1"|awk -F "=" '{print $NF}' )`date +_%Y%m%d-%H%M`
echo "ro.fota.version=$FotaVersion" | sed  's/[^0-9a-zA-Z= ._-]//g'
echo "# end fota properties"
#********Do not modify this file. If you want modify this file, pls contact our FAE*******
