#!/bin/bash

ROOTPATH="target_files-package"
mkdir -p $ROOTPATH
#build
mkdir -p  $ROOTPATH/build/target/product/
cp -a build/target/product/security/  $ROOTPATH/build/target/product/
mkdir -p $ROOTPATH/build/tools/
cp -ur build/tools/releasetools/  $ROOTPATH/build/tools/
#out-bin
mkdir -p $ROOTPATH/out/host/linux-x86/bin/
cp -u out/host/linux-x86/bin/minigzip \
out/host/linux-x86/bin/aapt \
out/host/linux-x86/bin/mkbootfs \
out/host/linux-x86/bin/mkbootimg \
out/host/linux-x86/bin/fs_config \
out/host/linux-x86/bin/zipalign \
out/host/linux-x86/bin/bsdiff \
out/host/linux-x86/bin/imgdiff \
out/host/linux-x86/bin/make_ext4fs \
out/host/linux-x86/bin/mkuserimg.sh \
out/host/linux-x86/bin/mke2fs \
out/host/linux-x86/bin/mkuserimg_mke2fs.sh \
out/host/linux-x86/bin/e2fsdroid \
out/host/linux-x86/bin/mksquashfsimage.sh \
out/host/linux-x86/bin/mksquashfs \
out/host/linux-x86/bin/mkf2fsuserimg.sh \
out/host/linux-x86/bin/make_f2fs \
out/host/linux-x86/bin/simg2img \
out/host/linux-x86/bin/e2fsck \
out/host/linux-x86/bin/build_verity_tree \
out/host/linux-x86/bin/verity_signer \
out/host/linux-x86/bin/verity_verifier \
out/host/linux-x86/bin/append2simg \
out/host/linux-x86/bin/img2simg \
out/host/linux-x86/bin/boot_signer \
out/host/linux-x86/bin/fec \
out/host/linux-x86/bin/brillo_update_payload \
out/host/linux-x86/bin/delta_generator \
out/host/linux-x86/bin/bro \
$ROOTPATH/out/host/linux-x86/bin/
cp -ur out/host/linux-x86/bin/lib/ $ROOTPATH/out/host/linux-x86/bin/
#out-framework
mkdir -p $ROOTPATH/out/host/linux-x86/framework
cp -u out/host/linux-x86/framework/dumpkey.jar \
out/host/linux-x86/framework/signapk.jar \
out/host/linux-x86/framework/BootSignature.jar \
out/host/linux-x86/framework/VeritySigner.jar \
$ROOTPATH/out/host/linux-x86/framework/
#out-lib/lib64
mkdir -p $ROOTPATH/$4/
cp -u $4/libc++$5 \
$4/liblog$5 \
$4/libcutils$5 \
$4/libselinux$5 \
$4/libcrypto-host$5 \
$4/libext2fs-host$5 \
$4/libext2_blkid-host$5 \
$4/libext2_com_err-host$5 \
$4/libext2_e2p-host$5 \
$4/libext2_misc$5 \
$4/libext2_profile-host$5 \
$4/libext2_quota-host$5 \
$4/libext2_uuid-host$5 \
$4/libconscrypt_openjdk_jni$5 \
$4/libbrillo$5 \
$4/libbrillo-stream$5 \
$4/libchrome$5 \
$4/libcurl-host$5 \
$4/libevent-host$5 \
$4/libprotobuf-cpp-lite$5 \
$4/libssl-host$5 \
$4/libz-host$5 \
$4/libsparse-host$5 \
$4/libbase$5 \
$4/libpcre2$5 \
$4/libbrotli$5 \
$ROOTPATH/$4/
#ota_scatter
cp -u $1/ota_scatter.txt  $ROOTPATH/out/target/product/$3/
#system
mkdir -p $ROOTPATH/system/extras/verity/
cp -u system/extras/verity/build_verity_metadata.py $ROOTPATH/system/extras/verity/
#mkdir -p $ROOTPATH/out/host/linux-x86/lib64/
#vendor
mkdir -p $ROOTPATH/vendor/mediatek/proprietary/custom/$3/
cp -ur vendor/mediatek/proprietary/custom/$3/security/  $ROOTPATH/vendor/mediatek/proprietary/custom/$3/
mkdir -p $ROOTPATH/vendor/mediatek/proprietary/scripts/
cp -ur vendor/mediatek/proprietary/scripts/releasetools/  $ROOTPATH/vendor/mediatek/proprietary/scripts/
#device
mkdir -p $ROOTPATH/device/mediatek/
cp -ur device/mediatek/security/  $ROOTPATH/device/mediatek/
mkdir -p $ROOTPATH/device/mediatek/common/
cp -ur device/mediatek/common/security/  $ROOTPATH/device/mediatek/common/
mkdir -p $ROOTPATH/device/mediatek/build/
cp -ur device/mediatek/build/releasetools/  $ROOTPATH/device/mediatek/build/
#system_image_info
mkdir -p $ROOTPATH/out/target/product/$3/root/
cp -u $1/obj/PACKAGING/systemimage_intermediates/system_image_info.txt $ROOTPATH/
cp -u $1/root/file_contexts.bin  $ROOTPATH/out/target/product/$3/root/
#scatter
cp -u $1/ota_scatter.txt $ROOTPATH/scatter.txt
#target_files
if [ $# -ge 6 ] && [ $6 = IMG ] ; then
cp -u $1/img-target-files.zip $ROOTPATH/ota_target_files.zip
mkdir -p IMAGES/
cp -u $1/obj/KERNEL_OBJ/System.map IMAGES/System.map
zip -q $ROOTPATH/ota_target_files.zip IMAGES/System.map
rm -rf IMAGES
cp $1/obj/KERNEL_OBJ/System.map $1/System.map
else
echo `ls -lrt $1/obj/PACKAGING/target_files_intermediates/*target_files*.zip|tail -n 1|awk '{print $NF}'`
cp -u `ls -lrt $1/obj/PACKAGING/target_files_intermediates/*target_files*.zip|tail -n 1|awk '{print $NF}'`  $ROOTPATH/ota_target_files.zip
if [ $# -ge 6 ] && [ $6 = sign_image ] ; then
mkdir -p IMAGES/
cp -u $1/lk-sign.bin IMAGES/lk.bin
cp -u $1/logo-sign.bin IMAGES/logo.bin
cp -u $1/boot-sign.img IMAGES/boot.img
cp -u $1/recovery-sign.img IMAGES/recovery.img
cp -u $1/system-sign.img IMAGES/system.img
cp -u $1/lk-verified.bin IMAGES/lk.bin
cp -u $1/logo-verified.bin IMAGES/logo.bin
cp -u $1/boot-verified.img IMAGES/boot.img
cp -u $1/recovery-verified.img IMAGES/recovery.img
cp -u $1/system-verified.img IMAGES/system.img
cp -u $1/preloader_*.bin IMAGES/
zip -q $ROOTPATH/ota_target_files.zip IMAGES/*
rm -rf IMAGES
fi
#simply the package
mkdir -p SYSTEM/
cp -u $1/system/build.prop SYSTEM/build.prop
cp -u $1/system/recovery-from-boot.p SYSTEM/recovery-from-boot.p
#zip -d $ROOTPATH/ota_target_files.zip SYSTEM/*
#zip -q $ROOTPATH/ota_target_files.zip SYSTEM/build.prop SYSTEM/recovery-from-boot.p
rm -rf SYSTEM
fi

#build.prop
cp -u $1/system/build.prop $ROOTPATH/build.prop

if [ $# -ge 6 ] && [ $6 = sign_image ] ; then
cp -u $1/lk-sign.bin $ROOTPATH/lk.bin
cp -u $1/logo-sign.bin $ROOTPATH/logo.bin
cp -u $1/lk-verified.bin $ROOTPATH/lk.bin
cp -u $1/logo-verified.bin $ROOTPATH/logo.bin
cp -u $1/preloader*.bin $ROOTPATH/
else
cp -u $1/lk.bin $ROOTPATH/lk.bin
cp -u $1/logo.bin $ROOTPATH/logo.bin
fi

#configure.xml
echo "">$ROOTPATH/configure.xml
echo "<root>">>$ROOTPATH/configure.xml

#buildnumber
var=$(grep  "ro.fota.version=" "$1/system/build.prop" )
buildnumber=${var##"ro.fota.version="}
echo "<buildnumber>$buildnumber</buildnumber>">>$ROOTPATH/configure.xml

#language
if [ -n "`grep "ro.fota.language=" $1/system/build.prop`" ] ; then
    var=$(grep  "ro.fota.language=" "$1/system/build.prop" )
    echo "<language>${var##"ro.fota.language="}</language>">>$ROOTPATH/configure.xml
elif [ -n "`grep "ro.product.locale=" $1/system/build.prop`" ] ; then
    var=$(grep  "ro.product.locale=" "$1/system/build.prop" )
    echo "<language>${var##"ro.product.locale="}</language>">>$ROOTPATH/configure.xml
elif [ -n "`grep "ro.product.locale.language=" $1/system/build.prop`" ] ; then
    var=$(grep  "ro.product.locale.language=" "$1/system/build.prop" )
    echo "<language>${var##"ro.product.locale.language="}</language>">>$ROOTPATH/configure.xml
else
    echo "<language>en</language>">>$ROOTPATH/configure.xml
fi

#oem
var=$(grep  "ro.fota.oem=" "$1/system/build.prop" )
echo "<oem>${var##"ro.fota.oem="}</oem>">>$ROOTPATH/configure.xml

#operator
var=$(grep  "ro.operator.optr=" "$1/system/build.prop")
if [ "$var" = "" ] ; then
  var=other
else
var=$(echo $var|tr A-Z a-z)
if [ ${var##"ro.operator.optr="} = op01 ] ; then
var=CMCC
elif [ ${var##"ro.operator.optr="} = op02 ] ; then
var=CU
else
var=other
fi
fi
echo "<operator>${var##"ro.operator.optr="}</operator>">>$ROOTPATH/configure.xml

#model
var=$(grep  "ro.fota.device=" "$1/system/build.prop" )
product=${var##"ro.fota.device="}
echo "<product>$product</product>">>$ROOTPATH/configure.xml

#publishtime
echo "<publishtime>$(date +20%y%m%d%H%M%S)</publishtime>">>$ROOTPATH/configure.xml

#versionname
echo "<versionname>$buildnumber</versionname>">>$ROOTPATH/configure.xml
#key
echo "<key>$2</key>">>$ROOTPATH/configure.xml
echo "</root>">>$ROOTPATH/configure.xml

if [ $# -ge 6 ] && [ $6 = sign_image ] ; then
if [ -f $1/target_files-package-sign.zip ]; then
echo "delete exist file:$1/target_files-package"
rm -f $1/target_files-package-sign.zip
fi
else
if [ -f $1/target_files-package.zip ]; then
echo "delete exist file:$1/target_files-package"
rm -f $1/target_files-package.zip
fi
fi

if [ -f $1/img-target-files.zip ]; then
echo "delete exist file:$1/img-target-files.zip"
rm -f $1/img-target-files.zip
fi

cd target_files-package
zip -rq target_files-package.zip build device out vendor system configure.xml build.prop lk.bin logo.bin scatter.txt ota_target_files.zip system_image_info.txt
cd ..
if [ $# -ge 6 ] && [ $6 = sign_image ] ; then
mv target_files-package/target_files-package.zip $1/target_files-package-sign.zip
else
mv target_files-package/target_files-package.zip $1/target_files-package.zip
fi
rm -rf target_files-package

